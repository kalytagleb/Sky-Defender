package model.enemies;

/**
 * Enum representing different types of enemies
 */
public enum EnemyType {
    BASIC,
    FAST,
    TANK
}